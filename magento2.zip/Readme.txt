#Installation

Magento2 Product Pre-Order module's installation is very easy, please follow the steps for installation-

1. Unzip the respective extension zip and then move "app" folder (inside "src" folder) into magento root directory.

Run Following Command via terminal
-----------------------------------
php bin/magento setup:upgrade
php bin/magento setup:di:compile
php bin/magento setup:static-content:deploy

2. Flush the cache and reindex all.

now module is properly installed

#User Guide

For Magento2 Product Pre-Order module's working process follow user guide - http://webkul.com/blog/magento2-preorder/

#Support

Find our support policy - https://store.webkul.com/support.html/

#Refund

Find our refund policy - https://store.webkul.com/refund-policy.html/

----------------------------------------------------------------------------------------
Note - This readme file is strictly need to use when you have purchased the software from 
webkul store i.e https://store.webkul.com . If you purchase the module from magento marketplace 
connect this readme file will not work.